from django.contrib import admin
from logs.models import Log

admin.site.register(Log)